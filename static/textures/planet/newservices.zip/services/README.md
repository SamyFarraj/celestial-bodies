# Services App

## server_side_(back-end)
It's an Application build by Laravel Framework and MySql database
it contains reservation system to serve a construction project  
## technical_features:
1. MultiAuth system using guards with Passport package
2. verify account using verification code which sent by E-mail


## Run_this_project
1. run the server and mysql using one of this programmes(Wamp,LAMP,XAMPP ).
2. creat Database and link it with project.
3.write this command "php artisan serve" in command line Inside the project folder .
